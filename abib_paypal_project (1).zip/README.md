# ABIB Netlify Project with PayPal ✅

Includes:
- PayPal Smart Buttons
- Hidden Admin Login
- Next.js Export for Netlify

## Setup
1️⃣ Install:
```
npm install
```

2️⃣ Add PayPal Client ID:
Create `.env.local`:
```
NEXT_PUBLIC_PAYPAL_CLIENT_ID=YOUR_CLIENT_ID
```

3️⃣ Build static export:
```
npm run build
npm run export
```

4️⃣ Deploy `out` folder on Netlify 🎯

## Pages
- `/` Home
- `/checkout` PayPal checkout
- `/admin/login` Admin (hidden)

