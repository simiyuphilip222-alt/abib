import { useState } from 'react'
import { useRouter } from 'next/router'

export default function Login(){
  const [email,setEmail]=useState('')
  const [pass,setPass]=useState('')
  const router = useRouter()
  const handle=(e)=>{
    e.preventDefault()
    if(email === 'admin@example.com' && pass === 'password123'){
      localStorage.setItem('abib_admin','1')
      router.push('/admin/dashboard')
    } else alert('Invalid')
  }
  return (
    <div className="container">
      <h2>Admin Login (Hidden)</h2>
      <form onSubmit={handle}>
        <label>Email<input value={email} onChange={e=>setEmail(e.target.value)}/></label><br/>
        <label>Password<input type="password" value={pass} onChange={e=>setPass(e.target.value)}/></label><br/>
        <button type="submit">Login</button>
      </form>
    </div>
  )
}
