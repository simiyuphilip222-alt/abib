import { useEffect } from 'react'
import { useRouter } from 'next/router'

export default function Dashboard(){
  const router = useRouter()
  useEffect(()=>{
    if(!localStorage.getItem('abib_admin')) router.replace('/admin/login')
  },[])
  return (
    <div className="container">
      <h2>Admin Dashboard</h2>
      <p>Manage your store (Feature coming...)</p>
    </div>
  )
}
