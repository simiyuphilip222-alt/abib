import { useEffect } from 'react'

export default function Checkout(){
  useEffect(()=>{
    const script = document.createElement("script")
    script.src = `https://www.paypal.com/sdk/js?client-id=${process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID || 'test'}`
    script.addEventListener("load", ()=>{
      if(window.paypal){
        window.paypal.Buttons({
          createOrder: function (data, actions) {
            return actions.order.create({
              purchase_units: [{ amount: { value: '10.00' } }]
            })
          },
          onApprove: function (data, actions) {
            return actions.order.capture().then(function () {
              alert("✅ Payment Success! Order captured.")
            })
          }
        }).render('#paypal-button-container')
      }
    })
    document.body.appendChild(script)
  },[])

  return (
    <div className="container">
      <h2>Checkout</h2>
      <p>Pay KES or USD through PayPal.</p>
      <div id="paypal-button-container"></div>
    </div>
  )
}
