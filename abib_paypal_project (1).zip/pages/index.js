import Link from 'next/link'
export default function Home(){
  return (
    <div className="container">
      <h1>ABIB Store</h1>
      <p>PayPal enabled demo.</p>
      <Link href="/checkout">Go to Checkout</Link><br/>
      <Link href="/admin/login">Admin Login</Link>
    </div>
  )
}
