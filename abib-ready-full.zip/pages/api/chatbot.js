export default function handler(req,res){ res.status(200).json({ reply: 'Hello from chatbot (demo).' }) }
