
import { useRouter } from 'next/router'
import { sampleProducts } from '../../data/sampleProducts'
export default function Product(){ const r = useRouter(); const { id } = r.query; const p = sampleProducts.find(s=>s.id===id) || sampleProducts[0]; return (<div style={{padding:20}}><h1>{p.title}</h1><p>{p.description}</p></div>) }
