
import Link from 'next/link'
export default function Home(){ return (<div style={{padding:20}}>Abib Home - copy .env and run. <div><Link href='/product/p1'>Sample product</Link></div></div>) }
