export const sampleProducts = [{ id: 'p1', title: 'Comfy Wireless Earbuds', price:49.99, image:'/images/earbuds.jpg', description:'Clear sound.' }];
