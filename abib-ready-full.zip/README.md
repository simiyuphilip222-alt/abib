# Abib.com - Ready project

Unzip and follow .env.example to run locally.
