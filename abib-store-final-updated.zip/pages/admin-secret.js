export default function AdminSecret() {
  return (
    <div className="p-6">
      <h1 className="text-2xl">Admin Dashboard (Hidden)</h1>
      <p className="mt-4">From here you can add products via the add product page: <a className="text-green-600" href="/admin/add-product">Add Product</a></p>
    </div>
  );
}
