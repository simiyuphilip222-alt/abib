export default function Checkout() {
  return (
    <div className="p-6">
      <h2 className="text-2xl">Checkout (Demo)</h2>
      <p className="mt-4">Payments are not yet configured. Use the admin to add products. For live payments we will integrate Stripe and/or M-Pesa — please provide API keys.</p>
    </div>
  );
}
