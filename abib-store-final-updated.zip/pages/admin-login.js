import { useState } from 'react';
export default function AdminLogin() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    const res = await fetch('/api/admin/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password })
    });
    if (res.ok) {
      // redirect to admin secret
      window.location.href = '/admin-secret';
    } else {
      const txt = await res.text();
      setError(txt || 'Invalid password');
    }
  }
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-full max-w-md p-8 border rounded">
        <h2 className="text-2xl mb-4">Admin Login</h2>
        <form onSubmit={handleSubmit}>
          <input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full p-2 border mb-2" />
          <button className="w-full bg-green-600 text-white p-2 rounded">Enter Admin</button>
        </form>
        {error && <p className="text-red-600 mt-2">{error}</p>}
      </div>
    </div>
  );
}
