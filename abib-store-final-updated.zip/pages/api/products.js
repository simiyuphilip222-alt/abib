let PRODUCTS = [];
export default function handler(req, res) {
  if (req.method === 'GET') {
    return res.status(200).json({ products: PRODUCTS });
  }
  if (req.method === 'POST') {
    const { title, price } = req.body || {};
    const id = Date.now().toString();
    PRODUCTS.unshift({ id, title, price, created_at: new Date().toISOString() });
    return res.status(201).json({ ok: true, id });
  }
  return res.status(405).end('Method not allowed');
}
