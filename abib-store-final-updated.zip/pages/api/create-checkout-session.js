// Placeholder Stripe API. Add STRIPE_SECRET_KEY to .env.local and implement real session creation.
export default async function handler(req, res) {
  return res.status(501).json({ error: 'Not implemented. Add STRIPE_SECRET_KEY and enable Stripe integration.' });
}
