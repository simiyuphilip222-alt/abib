export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end('Method not allowed');
  const { password } = req.body || {};
  const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change-me-strong-password';
  if (password === ADMIN_PASSWORD) {
    return res.status(200).end('ok');
  } else {
    return res.status(401).end('Invalid password');
  }
}
